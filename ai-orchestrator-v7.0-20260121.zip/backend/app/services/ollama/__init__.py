"""Ollama service module"""
from .client import ollama_client

__all__ = ["ollama_client"]
